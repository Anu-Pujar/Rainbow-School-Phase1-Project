﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RainbowSchool
{/*
    class SelectionSort
    {
        public int[] sort(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                var minIndex = i;
                for (int j = i; j < array.Length; j++)
                {
                    if (array[j] < array[minIndex])
                        minIndex = j;
                    swap(array, minIndex, i);
                }
            }
            return array;
        }
        private void swap(int[] array, int index1, int index2)
        {
            var temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 9, 7, 4, 0, 2, 1 };
            SelectionSort sorter = new SelectionSort();

            Array.ForEach(sorter.sort(numbers), n => Console.WriteLine(n));
            Console.ReadKey();
        }
    }
*/
    class Teachers
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string ClassSection { get; set; }


        public Teachers(int id, string name, string classSection)
        {
            ID = id;
            Name = name;
            ClassSection = classSection;
        }
    }
    class PayrollBillingSysytem
    {
        public void DisplayTeachersDetails(List<Teachers> listTeachers)
        {
            foreach (Teachers teachers in listTeachers)
            {
                Console.WriteLine("Teacher {0} is from {1}",teachers.Name,teachers.ClassSection );
            }
        }
    }
    interface ITarget
    {
        void ProcessCompanySalary(string[,] employeeArray);
    }
    class EmployeeAdapter : ITarget
    {
        public void ProcessCompanySalary(string[,] teacherArray)
        {
            string Id = null;
            string Name = null;
            string ClassSection = null;
           
            List<Teachers> listTeacher = new List<Teachers>();
            PayrollBillingSysytem PayrollBilling = new PayrollBillingSysytem();
            for (int i = 0; i < teacherArray.GetLength(0); i++)
            {
                for (int j = 0; j < teacherArray.GetLength(1); j++)
                {
                    if (j == 0)
                    {
                        Id = teacherArray[i, j];
                    }
                    if (j == 1)
                    {
                        Name = teacherArray[i, j];
                    }
                    if (j == 2)
                    {
                        ClassSection = teacherArray[i, j];
                    }
                    
                }
                listTeacher.Add(new Teachers(Convert.ToInt32(Id), Name, ClassSection));
            }
            PayrollBilling.DisplayTeachersDetails(listTeacher);
        }
    }
    class AdapterDesignPattern
    {
        static void Main(string[] args)
        {
            string[,] teacherArray = new string[5, 3]
            {
                {"101","Anuradha","Section A" },
                {"102","Pavan","Section B" },
                {"103","Nitisha","Section A" },
                {"104","Mantra","Section C" },
                {"105","Aashrita","Section C"}
            };
            ITarget target = new EmployeeAdapter();
            Console.WriteLine("Rainbow School Teachers Deatils");
            Console.WriteLine("-----------------------------------------");
            target.ProcessCompanySalary(teacherArray);
            Console.ReadKey();

        }
    }
}
